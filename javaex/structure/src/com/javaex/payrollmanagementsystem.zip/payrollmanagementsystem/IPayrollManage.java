package javaex.structure.src.com.javaex.payrollmanagementsystem;

public interface IPayrollManage {

    double pay = 0;

    public double getSalary(Position pos);

}

