package javaex.structure.src.com.javaex.gradeprogram_map;

public class GradeApp {

 
    public static void main(String[] args) {
        
        Init makeApp = new Init();
        makeApp.Start();

    }
    
}
