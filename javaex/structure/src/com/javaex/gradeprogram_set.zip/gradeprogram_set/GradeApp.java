package javaex.structure.src.com.javaex.gradeprogram_set;

public class GradeApp {

 
    public static void main(String[] args) {
        
        Init makeApp = new Init();
        makeApp.Start();

    }
    
}
